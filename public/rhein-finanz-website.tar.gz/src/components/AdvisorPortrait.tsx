import { useState, useEffect, SyntheticEvent } from 'react';

interface AdvisorPortraitProps {
  variant: 'hero' | 'about';
  className?: string;
}

export default function AdvisorPortrait({ variant, className = '' }: AdvisorPortraitProps) {
  const [photoUrl, setPhotoUrl] = useState<string>('/Facetune_06-04-2025-20-55-02-2.jpg');

  // Load photo from localStorage or fallback to static public asset
  useEffect(() => {
    const stored = localStorage.getItem('rf_hamo_photo');
    if (stored) {
      setPhotoUrl(stored);
    } else {
      setPhotoUrl('/Facetune_06-04-2025-20-55-02-2.jpg');
    }
  }, []);

  const handleImageError = (e: SyntheticEvent<HTMLImageElement, Event>) => {
    const target = e.currentTarget;
    if (!target.dataset.attempt) {
      target.dataset.attempt = '1';
      target.src = '/hamo-hussein.jpg';
    } else if (target.dataset.attempt === '1') {
      target.dataset.attempt = '2';
      target.src = '/profil.jpg';
    } else if (!target.dataset.fallback) {
      target.dataset.fallback = 'true';
      target.src = 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80';
    }
  };

  if (variant === 'hero') {
    return (
      <div className={`relative ${className}`}>
        <div className="relative w-11 h-11 rounded-full overflow-hidden border-2 border-[#c4a323] shrink-0 bg-gray-100 shadow-xs">
          <img
            src={photoUrl}
            alt="Hamo Hussein – Bankkaufmann & Inhaber Rhein-Finanz Meckenheim"
            className="w-full h-full object-cover object-top"
            referrerPolicy="no-referrer"
            onError={handleImageError}
          />
          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white" title="Direkt erreichbar" />
        </div>
      </div>
    );
  }

  // Variant === 'about'
  return (
    <div className={`relative w-full max-w-[280px] aspect-4/5 rounded-2xl overflow-hidden shadow-lg border-2 border-[#c4a323]/50 group bg-gray-200 ${className}`}>
      <img
        src={photoUrl}
        alt="Hamo Hussein – Bankkaufmann, Inhaber & Kreditentscheider Rhein-Finanz Meckenheim"
        className="w-full h-full object-cover object-top group-hover:scale-103 transition-transform duration-500"
        referrerPolicy="no-referrer"
        onError={handleImageError}
      />

      {/* Floating micro-badge */}
      <div className="absolute bottom-3 left-3 right-3 bg-[#1E2229]/95 backdrop-blur-xs text-white p-2.5 rounded-lg border border-[#c4a323]/40 text-center">
        <span className="block text-sm font-black text-white">Hamo Hussein</span>
        <span className="block text-xs font-bold text-[#c4a323]">Bankkaufmann & Inhaber</span>
        <span className="block text-[10px] text-gray-300">Rhein-Finanz Meckenheim • Direkter Kreditentscheider</span>
      </div>
    </div>
  );
}
